﻿Roope Rajala 2374556 roope.rajala@student.oulu.fi
Peetu Nuottajärvi 2374491 peetu.nuottajarvi@student.oulu.fi
Samuel Savikoski 2374637 samuel.savikoski@student.oulu.fi


Proxy is stand-alone

CLIENT ARGUMENTS:
-host [address], Set host address (default ii.virtues.fi)
-tcp [port], Set TCP port to connect to (default 10000)
-udp [port], Set UDP port to bind (default 9000)
-test, Test client with default arguments
-info or -help or -h, Show help message


PROXY ARGUMENTS:
-ip [address], Set server address (default: ii.virtues.fi)
-port [port], Set server port (default: 10000)
-test, Test proxy with default arguments
-info or -help or -h, Show help message